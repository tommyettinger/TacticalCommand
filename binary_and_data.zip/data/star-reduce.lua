
dofile "../extend.lua"

-- with code cribbed from earth.lua
local input, output = "heasarc_sao.tdat", "heasarc_sao_reduced_6.tdat"

local header = { }
local linefmt = { }

local function headerline(line)
	-- print(line)
	-- local k, _, d, v = string.match(line, "([%w_]+)(%[[%w_]+%])? = (.+)")
	local k, v = string.match(line, "([%w_%[%]]+)%s*=%s*(.+)")
	if k ~= nil then
		header[k] = v

		if k == "line[1]" then
			local idx = 1
			local columns = string.split(v, " ")
			for i, k in pairs(columns) do
				linefmt[k] = i
			end
		end
	end
end

local function dataline(line, starlist)
	-- read it according to linefmt, splitting on line
	local data = string.split(line, "|")
	local vmag = tonumber(data[linefmt.vmag])

	if vmag ~= nil and vmag < 6 then
		starlist[1 + #starlist] = {vmag, line}
	end
end

local function emitmap(starlist, out, output)
	print ("Writing starmap " .. output)
	table.sort(starlist, function(a, b)
		return a[1] > b[1]
	end)
	
	for i = 1, #starlist do
		out:write(starlist[i][2], "\n")
	end
	
	for i = #starlist, 1, -1 do
		starlist[i] = nil
	end
end

local function process()
	local mode = 0
	print ("Reducing starmap " .. input)
	local starlist = { }
	
	local out = io.open(output, "w")

	for line in io.lines(input) do
		local sw = string.byte(line, 1)
		if sw ~= string.byte "#" then
			if sw == string.byte "<" then
				if line == "<HEADER>" then
					mode = 1
				elseif line == "<DATA>" then
					mode = 2
				else
					if mode == 2 then
						emitmap(starlist, out, output)
					end
					mode = 0
				end
				out:write(line)
				out:write("\n")
			else
				if mode == 1 then
					headerline(line)
					out:write(line)
					out:write("\n")
				elseif mode == 2 then
					dataline(line, starlist)
				else
					out:write(line)
					out:write("\n")
				end
			end
		end
	end

	return starlist
end

process()

